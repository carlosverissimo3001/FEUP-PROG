T09_02


GROUP MEMBERS:

-Carlos Verissimo
-Nuno Jesus


PROGRAM DEVELOPMENT STATE:

- Generate random mazes -> DONE
- Read maze from existent file -> DONE
- Develop the main portion of the game -> DONE
- Write highscores in a seperate file -> HALF DONE


MAIN DIFFICULTIES:

- Devolopping portion of the code in which we had to read
highscores from a file and then rewrite again in the same file.


USAGE:

There are already 3 generated mazes (1, 2 and 3). If you wish to
play more mazes, compile mazeGenerator.cpp and choose how many
mazes you want to generate.

